var files_dup =
[
    [ "allocator.c", "allocator_8c.html", "allocator_8c" ],
    [ "createReaders.c", "create_readers_8c.html", "create_readers_8c" ],
    [ "createWriters.c", "create_writers_8c.html", "create_writers_8c" ],
    [ "dislocator.c", "dislocator_8c.html", "dislocator_8c" ],
    [ "MallocCheck.c", "_malloc_check_8c.html", "_malloc_check_8c" ],
    [ "MallocCheck.h", "_malloc_check_8h.html", "_malloc_check_8h" ],
    [ "monitor.c", "monitor_8c.html", "monitor_8c" ],
    [ "reader.c", "reader_8c.html", "reader_8c" ],
    [ "SharedStruct.c", "_shared_struct_8c.html", "_shared_struct_8c" ],
    [ "SharedStruct.h", "_shared_struct_8h.html", "_shared_struct_8h" ],
    [ "timer.c", "timer_8c.html", "timer_8c" ],
    [ "write.c", "write_8c.html", "write_8c" ]
];