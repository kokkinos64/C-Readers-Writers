var _shared_struct_8h =
[
    [ "shared_struct", "structshared__struct.html", "structshared__struct" ],
    [ "TABLESIZE", "_shared_struct_8h.html#a1baf7829bbaab1395a13dc5ff8d1b1c3", null ],
    [ "SharedStruct", "_shared_struct_8h.html#a94b981a0d8b55e2c53f0ac3d708eac74", null ],
    [ "AppendReader", "_shared_struct_8h.html#ae56dddc8b440696984aaa26b5c0ae6e0", null ],
    [ "AppendWriter", "_shared_struct_8h.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb", null ],
    [ "PrintTables", "_shared_struct_8h.html#a060bc28e2dce04b6f10b3d484c8aff0b", null ],
    [ "RemoveReader", "_shared_struct_8h.html#a53aa7dc84bda48d20a232e3abd077bba", null ],
    [ "RemoveWriter", "_shared_struct_8h.html#ad84a870c4b13354265d849dcaabba934", null ],
    [ "SubmitTimeToStart", "_shared_struct_8h.html#a01c7c9b0be0acea00b4e2d01279c60c0", null ]
];