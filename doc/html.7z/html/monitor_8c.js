var monitor_8c =
[
    [ "SEM_PERMS", "monitor_8c.html#abd56a6c992ac7c046d6571fb92496527", null ],
    [ "TABLESIZE", "monitor_8c.html#a1baf7829bbaab1395a13dc5ff8d1b1c3", null ],
    [ "InitSemaphores", "monitor_8c.html#aa6cd4836edb6ee9036d3d4cef0d68893", null ],
    [ "main", "monitor_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "PrintArrays", "monitor_8c.html#a6187ff0365b0a895a3fb95afe1763c81", null ],
    [ "PrintCounts", "monitor_8c.html#a42988b80aa8f98ff6bac6b8fa5b9bf1a", null ],
    [ "PrintNumbers", "monitor_8c.html#a7702d29247b84293092209153599f400", null ],
    [ "PrintSemaphoreValues", "monitor_8c.html#acc88c298b2dda4df46049f1062e1ae25", null ],
    [ "ReadSemaphores", "monitor_8c.html#ae11d86ec79a28f6dd5207d2c3e6029e5", null ],
    [ "mutex", "monitor_8c.html#a9b044b36aa51f6b7a4c9fc725e0a274e", null ],
    [ "mutex_Value", "monitor_8c.html#ae1748004c87b47fcdaa66d6e8d1e7c2b", null ],
    [ "queue", "monitor_8c.html#a982550db21b64d5cac1bf89e9bb98ad6", null ],
    [ "queue_Value", "monitor_8c.html#aceed62bebf00c0fbcbbe48f7c1f5df9c", null ],
    [ "wrt", "monitor_8c.html#a878e4bed8ecaeb14b923ee3198a0b877", null ],
    [ "wrt_Value", "monitor_8c.html#a9cb55fcb0f7f19d786860a9887319ea0", null ]
];