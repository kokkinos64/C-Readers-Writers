var structshared__struct =
[
    [ "ActiveReaders", "structshared__struct.html#aa694bf2ef26d1bec5eb5aa34e5eae9f5", null ],
    [ "ActiveReadersCount", "structshared__struct.html#aaf7c66a0b5e51ec97f860e1397c186a8", null ],
    [ "ActiveWriters", "structshared__struct.html#a9cda7e09d20a8ad80d0783af936662a5", null ],
    [ "ActiveWritersCount", "structshared__struct.html#abd0ef6b63c297223e041ed94cbdc3e77", null ],
    [ "MaxTimeToStart", "structshared__struct.html#acbc54355cedb1de0e3afb8f3683d5736", null ],
    [ "ReadersCompleted", "structshared__struct.html#aec97707f84671a3e39604ecfb99253ec", null ],
    [ "ReadersTimeSum_REAL", "structshared__struct.html#a1ebec44b48dbe1ba224249660ed45691", null ],
    [ "RecordsProcessed", "structshared__struct.html#a334e4e2744707ab60cfba58f1aec7922", null ],
    [ "WritersCompleted", "structshared__struct.html#a80dc118c00ad408383106ee769e1b473", null ],
    [ "WritersTimeSum_REAL", "structshared__struct.html#a5ebedd59d86f87b1d80765b5e318ecba", null ]
];