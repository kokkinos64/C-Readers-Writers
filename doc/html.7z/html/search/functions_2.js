var searchData=
[
  ['detachsegment_0',['DetachSegment',['../_malloc_check_8c.html#a792b3e97cb3bc5f4ce99c689355fb2b6',1,'DetachSegment(void *seg_pointer):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a792b3e97cb3bc5f4ce99c689355fb2b6',1,'DetachSegment(void *seg_pointer):&#160;MallocCheck.c']]],
  ['doesreaderexist_1',['DoesReaderExist',['../_shared_struct_8c.html#a071146f2650d4fd58a93d4320ef261cd',1,'SharedStruct.c']]],
  ['doeswriterexist_2',['DoesWriterExist',['../_shared_struct_8c.html#a96e8f403d2e5ba37b91d17e1c2258b07',1,'SharedStruct.c']]]
];
