var searchData=
[
  ['activereaders_0',['ActiveReaders',['../structshared__struct.html#aa694bf2ef26d1bec5eb5aa34e5eae9f5',1,'shared_struct']]],
  ['activereaderscount_1',['ActiveReadersCount',['../structshared__struct.html#aaf7c66a0b5e51ec97f860e1397c186a8',1,'shared_struct']]],
  ['activewriters_2',['ActiveWriters',['../structshared__struct.html#a9cda7e09d20a8ad80d0783af936662a5',1,'shared_struct']]],
  ['activewriterscount_3',['ActiveWritersCount',['../structshared__struct.html#abd0ef6b63c297223e041ed94cbdc3e77',1,'shared_struct']]]
];
