var searchData=
[
  ['createreaders_2ec_0',['createReaders.c',['../create_readers_8c.html',1,'']]],
  ['createwriters_2ec_1',['createWriters.c',['../create_writers_8c.html',1,'']]]
];
