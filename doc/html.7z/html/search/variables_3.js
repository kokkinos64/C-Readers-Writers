var searchData=
[
  ['readerscompleted_0',['ReadersCompleted',['../structshared__struct.html#aec97707f84671a3e39604ecfb99253ec',1,'shared_struct']]],
  ['readerstimesum_5freal_1',['ReadersTimeSum_REAL',['../structshared__struct.html#a1ebec44b48dbe1ba224249660ed45691',1,'shared_struct']]],
  ['recordsprocessed_2',['RecordsProcessed',['../structshared__struct.html#a334e4e2744707ab60cfba58f1aec7922',1,'shared_struct']]]
];
