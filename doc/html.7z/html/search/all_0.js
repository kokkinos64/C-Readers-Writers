var searchData=
[
  ['activereaders_0',['ActiveReaders',['../structshared__struct.html#aa694bf2ef26d1bec5eb5aa34e5eae9f5',1,'shared_struct']]],
  ['activereaderscount_1',['ActiveReadersCount',['../structshared__struct.html#aaf7c66a0b5e51ec97f860e1397c186a8',1,'shared_struct']]],
  ['activewriters_2',['ActiveWriters',['../structshared__struct.html#a9cda7e09d20a8ad80d0783af936662a5',1,'shared_struct']]],
  ['activewriterscount_3',['ActiveWritersCount',['../structshared__struct.html#abd0ef6b63c297223e041ed94cbdc3e77',1,'shared_struct']]],
  ['allocator_4',['Allocator',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['allocator_2ec_5',['allocator.c',['../allocator_8c.html',1,'']]],
  ['and_20createwriters_6',['createReaders and createWriters',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['and_20writer_20programs_7',['Reader and Writer programs',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['appendreader_8',['AppendReader',['../_shared_struct_8c.html#ae56dddc8b440696984aaa26b5c0ae6e0',1,'AppendReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ae56dddc8b440696984aaa26b5c0ae6e0',1,'AppendReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c']]],
  ['appendwriter_9',['AppendWriter',['../_shared_struct_8c.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb',1,'AppendWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb',1,'AppendWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c']]],
  ['attachsegment_10',['AttachSegment',['../_malloc_check_8c.html#a1ba310479aacc9d8e75b2e3c5344a6f4',1,'AttachSegment(int seg_id):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a1ba310479aacc9d8e75b2e3c5344a6f4',1,'AttachSegment(int seg_id):&#160;MallocCheck.c']]]
];
