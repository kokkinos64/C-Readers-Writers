var searchData=
[
  ['appendreader_0',['AppendReader',['../_shared_struct_8c.html#ae56dddc8b440696984aaa26b5c0ae6e0',1,'AppendReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ae56dddc8b440696984aaa26b5c0ae6e0',1,'AppendReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c']]],
  ['appendwriter_1',['AppendWriter',['../_shared_struct_8c.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb',1,'AppendWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb',1,'AppendWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c']]],
  ['attachsegment_2',['AttachSegment',['../_malloc_check_8c.html#a1ba310479aacc9d8e75b2e3c5344a6f4',1,'AttachSegment(int seg_id):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a1ba310479aacc9d8e75b2e3c5344a6f4',1,'AttachSegment(int seg_id):&#160;MallocCheck.c']]]
];
