var searchData=
[
  ['shared_5fstruct_0',['shared_struct',['../structshared__struct.html',1,'']]]
];
