var searchData=
[
  ['scanargumentsreader_0',['ScanArgumentsREADER',['../reader_8c.html#a92e3f120791be35f4c09468601e66269',1,'reader.c']]],
  ['scanargumentswriter_1',['ScanArgumentsWRITER',['../write_8c.html#a00a82676182122e1ed365d194798c069',1,'write.c']]],
  ['sem_5fperms_2',['SEM_PERMS',['../allocator_8c.html#abd56a6c992ac7c046d6571fb92496527',1,'SEM_PERMS:&#160;allocator.c'],['../dislocator_8c.html#abd56a6c992ac7c046d6571fb92496527',1,'SEM_PERMS:&#160;dislocator.c'],['../monitor_8c.html#abd56a6c992ac7c046d6571fb92496527',1,'SEM_PERMS:&#160;monitor.c'],['../reader_8c.html#abd56a6c992ac7c046d6571fb92496527',1,'SEM_PERMS:&#160;reader.c'],['../write_8c.html#abd56a6c992ac7c046d6571fb92496527',1,'SEM_PERMS:&#160;write.c']]],
  ['semaphorecheck_3',['SemaphoreCheck',['../_malloc_check_8c.html#ab4d4e65d1c569da61424ff6de6f0fd93',1,'SemaphoreCheck(sem_t *sem, char *sem_name):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a7c9d5c60cf34aff6fd4ad5d734f1defa',1,'SemaphoreCheck(sem_t *, char *):&#160;MallocCheck.c']]],
  ['shared_5fstruct_4',['shared_struct',['../structshared__struct.html',1,'']]],
  ['sharedstruct_5',['SharedStruct',['../_shared_struct_8h.html#a94b981a0d8b55e2c53f0ac3d708eac74',1,'SharedStruct.h']]],
  ['sharedstruct_2ec_6',['SharedStruct.c',['../_shared_struct_8c.html',1,'']]],
  ['sharedstruct_2eh_7',['SharedStruct.h',['../_shared_struct_8h.html',1,'']]],
  ['submittimetostart_8',['SubmitTimeToStart',['../_shared_struct_8c.html#a01c7c9b0be0acea00b4e2d01279c60c0',1,'SubmitTimeToStart(SharedStruct *s, double NewTime):&#160;SharedStruct.c'],['../_shared_struct_8h.html#a01c7c9b0be0acea00b4e2d01279c60c0',1,'SubmitTimeToStart(SharedStruct *s, double NewTime):&#160;SharedStruct.c']]]
];
