var searchData=
[
  ['getnumofrecords_0',['getNumOfRecords',['../reader_8c.html#a81c5bf82adfe9faadf07565a7588758c',1,'getNumOfRecords(char *filename):&#160;reader.c'],['../write_8c.html#a81c5bf82adfe9faadf07565a7588758c',1,'getNumOfRecords(char *filename):&#160;write.c']]]
];
