var searchData=
[
  ['initsemaphores_0',['InitSemaphores',['../monitor_8c.html#aa6cd4836edb6ee9036d3d4cef0d68893',1,'monitor.c']]]
];
