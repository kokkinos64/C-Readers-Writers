var searchData=
[
  ['write_2ec_0',['write.c',['../write_8c.html',1,'']]]
];
