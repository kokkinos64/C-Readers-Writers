var searchData=
[
  ['readsemaphores_0',['ReadSemaphores',['../monitor_8c.html#ae11d86ec79a28f6dd5207d2c3e6029e5',1,'monitor.c']]],
  ['removereader_1',['RemoveReader',['../_shared_struct_8c.html#a53aa7dc84bda48d20a232e3abd077bba',1,'RemoveReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#a53aa7dc84bda48d20a232e3abd077bba',1,'RemoveReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c']]],
  ['removesegment_2',['RemoveSegment',['../_malloc_check_8c.html#a02bf33ea8f0b3cd9a16742bcda825510',1,'RemoveSegment(int seg_id):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a02bf33ea8f0b3cd9a16742bcda825510',1,'RemoveSegment(int seg_id):&#160;MallocCheck.c']]],
  ['removewriter_3',['RemoveWriter',['../_shared_struct_8c.html#ad84a870c4b13354265d849dcaabba934',1,'RemoveWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ad84a870c4b13354265d849dcaabba934',1,'RemoveWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c']]]
];
