var searchData=
[
  ['c_20readers_20writers_0',['C-Readers-Writers',['../md__r_e_a_d_m_e.html',1,'']]],
  ['createreaders_20and_20createwriters_1',['createReaders and createWriters',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['createreaders_2ec_2',['createReaders.c',['../create_readers_8c.html',1,'']]],
  ['createsegment_3',['CreateSegment',['../_malloc_check_8c.html#a206e74f7bef42cf840ffa14d6e4b42dc',1,'CreateSegment(void):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a206e74f7bef42cf840ffa14d6e4b42dc',1,'CreateSegment(void):&#160;MallocCheck.c']]],
  ['createwriters_4',['createReaders and createWriters',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['createwriters_2ec_5',['createWriters.c',['../create_writers_8c.html',1,'']]]
];
