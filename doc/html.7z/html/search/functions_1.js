var searchData=
[
  ['createsegment_0',['CreateSegment',['../_malloc_check_8c.html#a206e74f7bef42cf840ffa14d6e4b42dc',1,'CreateSegment(void):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a206e74f7bef42cf840ffa14d6e4b42dc',1,'CreateSegment(void):&#160;MallocCheck.c']]]
];
