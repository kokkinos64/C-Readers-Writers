var searchData=
[
  ['reader_20and_20writer_20programs_0',['Reader and Writer programs',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['reader_2ec_1',['reader.c',['../reader_8c.html',1,'']]],
  ['readers_20writers_2',['C-Readers-Writers',['../md__r_e_a_d_m_e.html',1,'']]],
  ['readerscompleted_3',['ReadersCompleted',['../structshared__struct.html#aec97707f84671a3e39604ecfb99253ec',1,'shared_struct']]],
  ['readerstimesum_5freal_4',['ReadersTimeSum_REAL',['../structshared__struct.html#a1ebec44b48dbe1ba224249660ed45691',1,'shared_struct']]],
  ['readme_2emd_5',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readsemaphores_6',['ReadSemaphores',['../monitor_8c.html#ae11d86ec79a28f6dd5207d2c3e6029e5',1,'monitor.c']]],
  ['recordsprocessed_7',['RecordsProcessed',['../structshared__struct.html#a334e4e2744707ab60cfba58f1aec7922',1,'shared_struct']]],
  ['removereader_8',['RemoveReader',['../_shared_struct_8c.html#a53aa7dc84bda48d20a232e3abd077bba',1,'RemoveReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#a53aa7dc84bda48d20a232e3abd077bba',1,'RemoveReader(SharedStruct *s, pid_t reader_id):&#160;SharedStruct.c']]],
  ['removesegment_9',['RemoveSegment',['../_malloc_check_8c.html#a02bf33ea8f0b3cd9a16742bcda825510',1,'RemoveSegment(int seg_id):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a02bf33ea8f0b3cd9a16742bcda825510',1,'RemoveSegment(int seg_id):&#160;MallocCheck.c']]],
  ['removewriter_10',['RemoveWriter',['../_shared_struct_8c.html#ad84a870c4b13354265d849dcaabba934',1,'RemoveWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c'],['../_shared_struct_8h.html#ad84a870c4b13354265d849dcaabba934',1,'RemoveWriter(SharedStruct *s, pid_t writer_id):&#160;SharedStruct.c']]],
  ['run_11',['How to Run',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
