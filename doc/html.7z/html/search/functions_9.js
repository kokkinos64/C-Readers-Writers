var searchData=
[
  ['scanargumentsreader_0',['ScanArgumentsREADER',['../reader_8c.html#a92e3f120791be35f4c09468601e66269',1,'reader.c']]],
  ['scanargumentswriter_1',['ScanArgumentsWRITER',['../write_8c.html#a00a82676182122e1ed365d194798c069',1,'write.c']]],
  ['semaphorecheck_2',['SemaphoreCheck',['../_malloc_check_8c.html#ab4d4e65d1c569da61424ff6de6f0fd93',1,'SemaphoreCheck(sem_t *sem, char *sem_name):&#160;MallocCheck.c'],['../_malloc_check_8h.html#a7c9d5c60cf34aff6fd4ad5d734f1defa',1,'SemaphoreCheck(sem_t *, char *):&#160;MallocCheck.c']]],
  ['submittimetostart_3',['SubmitTimeToStart',['../_shared_struct_8c.html#a01c7c9b0be0acea00b4e2d01279c60c0',1,'SubmitTimeToStart(SharedStruct *s, double NewTime):&#160;SharedStruct.c'],['../_shared_struct_8h.html#a01c7c9b0be0acea00b4e2d01279c60c0',1,'SubmitTimeToStart(SharedStruct *s, double NewTime):&#160;SharedStruct.c']]]
];
