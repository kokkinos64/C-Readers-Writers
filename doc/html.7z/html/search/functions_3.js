var searchData=
[
  ['fileeditsingle_0',['FileEditSingle',['../write_8c.html#abbde43fe7937ec8a6738d95d9b77a603',1,'write.c']]],
  ['filereader_1',['FileReader',['../reader_8c.html#afbb85a6ada1e1bc9bfd3cc1c677b8d70',1,'reader.c']]],
  ['filereadersingle_2',['FileReaderSingle',['../reader_8c.html#abd3efa83857bdf115e4ad3d5bcaf1af4',1,'reader.c']]],
  ['forkreader_3',['ForkREADER',['../create_readers_8c.html#a998b6f76a4876fe83f214ed030d037ec',1,'createReaders.c']]],
  ['forkwriter_4',['ForkWRITER',['../create_writers_8c.html#a83384e831bb4639b9fefacd90226a458',1,'createWriters.c']]]
];
