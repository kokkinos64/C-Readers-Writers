var searchData=
[
  ['c_20readers_20writers_0',['C-Readers-Writers',['../md__r_e_a_d_m_e.html',1,'']]]
];
