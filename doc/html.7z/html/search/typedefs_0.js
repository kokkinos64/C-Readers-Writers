var searchData=
[
  ['sharedstruct_0',['SharedStruct',['../_shared_struct_8h.html#a94b981a0d8b55e2c53f0ac3d708eac74',1,'SharedStruct.h']]]
];
