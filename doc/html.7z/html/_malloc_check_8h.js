var _malloc_check_8h =
[
    [ "AttachSegment", "_malloc_check_8h.html#a1ba310479aacc9d8e75b2e3c5344a6f4", null ],
    [ "CreateSegment", "_malloc_check_8h.html#a206e74f7bef42cf840ffa14d6e4b42dc", null ],
    [ "DetachSegment", "_malloc_check_8h.html#a792b3e97cb3bc5f4ce99c689355fb2b6", null ],
    [ "MallocCheck", "_malloc_check_8h.html#ab4778d4c781f41147a556889b71005f4", null ],
    [ "RemoveSegment", "_malloc_check_8h.html#a02bf33ea8f0b3cd9a16742bcda825510", null ],
    [ "SemaphoreCheck", "_malloc_check_8h.html#a7c9d5c60cf34aff6fd4ad5d734f1defa", null ]
];