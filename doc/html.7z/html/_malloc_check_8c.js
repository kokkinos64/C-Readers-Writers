var _malloc_check_8c =
[
    [ "AttachSegment", "_malloc_check_8c.html#a1ba310479aacc9d8e75b2e3c5344a6f4", null ],
    [ "CreateSegment", "_malloc_check_8c.html#a206e74f7bef42cf840ffa14d6e4b42dc", null ],
    [ "DetachSegment", "_malloc_check_8c.html#a792b3e97cb3bc5f4ce99c689355fb2b6", null ],
    [ "MallocCheck", "_malloc_check_8c.html#ac51ad66029b0456dece216ced7d65285", null ],
    [ "RemoveSegment", "_malloc_check_8c.html#a02bf33ea8f0b3cd9a16742bcda825510", null ],
    [ "SemaphoreCheck", "_malloc_check_8c.html#ab4d4e65d1c569da61424ff6de6f0fd93", null ]
];