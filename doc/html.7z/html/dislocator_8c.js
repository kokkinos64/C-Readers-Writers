var dislocator_8c =
[
    [ "SEM_PERMS", "dislocator_8c.html#abd56a6c992ac7c046d6571fb92496527", null ],
    [ "main", "dislocator_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "mutex", "dislocator_8c.html#a9b044b36aa51f6b7a4c9fc725e0a274e", null ],
    [ "queue", "dislocator_8c.html#a982550db21b64d5cac1bf89e9bb98ad6", null ],
    [ "writesem", "dislocator_8c.html#a37c1bc471bf6817376140bc7d4a94dd8", null ]
];