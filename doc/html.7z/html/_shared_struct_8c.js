var _shared_struct_8c =
[
    [ "AppendReader", "_shared_struct_8c.html#ae56dddc8b440696984aaa26b5c0ae6e0", null ],
    [ "AppendWriter", "_shared_struct_8c.html#ab85dd91b0ea5afd8f5f84eb7ddf04dcb", null ],
    [ "DoesReaderExist", "_shared_struct_8c.html#a071146f2650d4fd58a93d4320ef261cd", null ],
    [ "DoesWriterExist", "_shared_struct_8c.html#a96e8f403d2e5ba37b91d17e1c2258b07", null ],
    [ "PrintTables", "_shared_struct_8c.html#a060bc28e2dce04b6f10b3d484c8aff0b", null ],
    [ "RemoveReader", "_shared_struct_8c.html#a53aa7dc84bda48d20a232e3abd077bba", null ],
    [ "RemoveWriter", "_shared_struct_8c.html#ad84a870c4b13354265d849dcaabba934", null ],
    [ "SubmitTimeToStart", "_shared_struct_8c.html#a01c7c9b0be0acea00b4e2d01279c60c0", null ]
];