var create_readers_8c =
[
    [ "ForkREADER", "create_readers_8c.html#a998b6f76a4876fe83f214ed030d037ec", null ],
    [ "main", "create_readers_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];