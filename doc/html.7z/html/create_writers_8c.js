var create_writers_8c =
[
    [ "ForkWRITER", "create_writers_8c.html#a83384e831bb4639b9fefacd90226a458", null ],
    [ "main", "create_writers_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];