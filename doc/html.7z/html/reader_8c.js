var reader_8c =
[
    [ "SEM_PERMS", "reader_8c.html#abd56a6c992ac7c046d6571fb92496527", null ],
    [ "FileReader", "reader_8c.html#afbb85a6ada1e1bc9bfd3cc1c677b8d70", null ],
    [ "FileReaderSingle", "reader_8c.html#abd3efa83857bdf115e4ad3d5bcaf1af4", null ],
    [ "getNumOfRecords", "reader_8c.html#a81c5bf82adfe9faadf07565a7588758c", null ],
    [ "main", "reader_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "ScanArgumentsREADER", "reader_8c.html#a92e3f120791be35f4c09468601e66269", null ],
    [ "mutex", "reader_8c.html#a9b044b36aa51f6b7a4c9fc725e0a274e", null ],
    [ "mutex_Value", "reader_8c.html#ae1748004c87b47fcdaa66d6e8d1e7c2b", null ],
    [ "queue", "reader_8c.html#a982550db21b64d5cac1bf89e9bb98ad6", null ],
    [ "queue_Value", "reader_8c.html#aceed62bebf00c0fbcbbe48f7c1f5df9c", null ],
    [ "write_Value", "reader_8c.html#af032642a0dc5fd199ec33e4319a58c4a", null ],
    [ "wrt", "reader_8c.html#a878e4bed8ecaeb14b923ee3198a0b877", null ]
];